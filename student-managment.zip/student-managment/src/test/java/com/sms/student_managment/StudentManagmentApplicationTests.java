package com.sms.student_managment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
